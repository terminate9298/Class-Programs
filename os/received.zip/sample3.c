#include<dirent.h>
#include<stdio.h>
#include<sys/types.h>
#include<unistd.h>
#include<stdlib.h>

main(int argc , char *argu[])
{
	DIR *dp;
	struct dirent *dirp;
	if(argc<2){
		printf("You have only provided 1 arguments");
		exit(1);
	}
	if((dp = opendir(argu[1]))==NULL){
		printf("cannot open File %s",argu[1]);
		exit(1);

	}
	while((dirp = readdir(dp))!=NULL)
		printf("%s\n",dirp->d_name);
	closedir(dp);
}