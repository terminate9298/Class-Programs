#include<stdio.h>
#include<sys/types.h>
#include<unistd.h>

int main(){

int t1=fork();
//printf("Hello\n");
//printf("%d\n",pi0);
//printf("%d\n",pi1);
//printf("Child ID -> %d Parent Id -> %d\n",getpid(),getppid());
if(t1>0){
	printf("Cannot create a process");
}
else if(t1==0){
	sleep(2);
	printf("This is a child process");
}
else
{
	printf("This is a parent process");
}
}
