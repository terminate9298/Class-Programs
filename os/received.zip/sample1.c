#include<stdio.h>
#include<sys/types.h>
#include<unistd.h>

int main(){

int t1=fork();
//printf("Hello\n");
//printf("%d\n",pi0);
//printf("%d\n",pi1);
//printf("Child ID -> %d Parent Id -> %d\n",getpid(),getppid());
if(t1==0){
	printf("Its zero \n I am Parent ID\n");
	printf("My pid is %d \n\n",getppid());
}
if(t1>0){
	printf("Its Greater than zero \n My Id id %d \n I am child Fork \n",t1);
	printf("My pid is %d \n\n",getppid());
}
if(t1<0){
	printf("Its Less than zero");
}
return 0;

}

